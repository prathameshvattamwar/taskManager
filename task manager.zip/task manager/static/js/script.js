document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const taskList = document.getElementById('taskList');
    const noTasksElement = document.getElementById('noTasks');
    const taskCount = document.getElementById('taskCount');
    const taskTemplate = document.getElementById('taskTemplate');
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const priorityFilter = document.getElementById('priorityFilter');
    const statusFilter = document.getElementById('statusFilter');
    const themeToggle = document.getElementById('themeToggle');
    
    // Task modal elements
    const taskModal = document.getElementById('taskModal');
    const modalTitle = document.getElementById('modalTitle');
    const taskForm = document.getElementById('taskForm');
    const taskIdInput = document.getElementById('taskId');
    const titleInput = document.getElementById('title');
    const descriptionInput = document.getElementById('description');
    const priorityInput = document.getElementById('priority');
    const categoryInput = document.getElementById('category');
    const dueDateInput = document.getElementById('due_date');
    const saveTaskBtn = document.getElementById('saveTaskBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const newTaskBtn = document.getElementById('newTaskBtn');
    
    // Task details modal elements
    const taskDetailsModal = document.getElementById('taskDetailsModal');
    const taskDetailsContent = document.getElementById('taskDetailsContent');
    
    // Stats elements
    const totalTasksElement = document.getElementById('totalTasks').querySelector('.stat-value');
    const completedTasksElement = document.getElementById('completedTasks').querySelector('.stat-value');
    const pendingTasksElement = document.getElementById('pendingTasks').querySelector('.stat-value');
    const completionRateElement = document.getElementById('completionRate').querySelector('.stat-value');
    
    // Close buttons for modals
    const closeButtons = document.querySelectorAll('.close');
    
    // ===== Theme Toggle =====
    themeToggle.addEventListener('change', function() {
        document.body.classList.toggle('dark-theme');
        document.body.classList.toggle('light-theme');
        
        // Save theme preference to localStorage
        localStorage.setItem('darkTheme', themeToggle.checked);
    });
    
    // Load theme preference
    if (localStorage.getItem('darkTheme') === 'true') {
        themeToggle.checked = true;
        document.body.classList.add('dark-theme');
        document.body.classList.remove('light-theme');
    }
    
    // ===== Fetch and Display Tasks =====
    function fetchTasks() {
        fetch('/api/tasks')
            .then(response => response.json())
            .then(tasks => {
                displayTasks(tasks);
                updateTaskCount(tasks.length);
                fetchStatistics();
            })
            .catch(error => {
                console.error('Error fetching tasks:', error);
            });
    }
    
    function displayTasks(tasks) {
        // Clear the task list
        taskList.innerHTML = '';
        
        if (tasks.length === 0) {
            noTasksElement.style.display = 'flex';
        } else {
            noTasksElement.style.display = 'none';
            
            // Create and append task elements
            tasks.forEach(task => {
                const taskElement = createTaskElement(task);
                taskList.appendChild(taskElement);
            });
        }
    }
    
    function createTaskElement(task) {
        const taskClone = document.importNode(taskTemplate.content, true);
        const taskItem = taskClone.querySelector('.task-item');
        
        // Set task data
        taskItem.dataset.id = task.id;
        
        // Set task content
        taskItem.querySelector('.task-title').textContent = task.title;
        
        const descriptionElement = taskItem.querySelector('.task-description');
        descriptionElement.textContent = task.description || 'No description';
        
        // Set priority badge
        const priorityBadge = taskItem.querySelector('.task-priority');
        priorityBadge.textContent = task.priority;
        priorityBadge.classList.add(`priority-${task.priority.toLowerCase()}`);
        
        // Set category badge
        const categoryBadge = taskItem.querySelector('.task-category');
        if (task.category) {
            categoryBadge.textContent = task.category;
        } else {
            categoryBadge.textContent = 'Uncategorized';
            categoryBadge.classList.add('category-none');
        }
        
        // Set due date
        const dueDateElement = taskItem.querySelector('.task-due-date');
        if (task.due_date) {
            const dueDate = new Date(task.due_date);
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            
            // Format the date
            const formattedDate = new Intl.DateTimeFormat('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
            }).format(dueDate);
            
            dueDateElement.innerHTML = `<i class="fas fa-calendar-alt"></i> Due: ${formattedDate}`;
            
            // Add styling for overdue tasks
            if (dueDate < today && !task.completed) {
                dueDateElement.classList.add('overdue');
            }
        } else {
            dueDateElement.style.display = 'none';
        }
        
        // Set completion status
        const checkbox = taskItem.querySelector('.task-complete-checkbox');
        checkbox.checked = task.completed;
        
        if (task.completed) {
            taskItem.classList.add('completed');
        }
        
        // Add event listeners to the task element
        setupTaskEventListeners(taskItem, task);
        
        return taskItem;
    }
    
    function setupTaskEventListeners(taskElement, task) {
        // Checkbox event listener
        const checkbox = taskElement.querySelector('.task-complete-checkbox');
        checkbox.addEventListener('change', function() {
            toggleTaskCompletion(task.id);
        });
        
        // View button event listener
        const viewBtn = taskElement.querySelector('.view-btn');
        viewBtn.addEventListener('click', function() {
            showTaskDetails(task);
        });
        
        // Edit button event listener
        const editBtn = taskElement.querySelector('.edit-btn');
        editBtn.addEventListener('click', function() {
            openEditTaskModal(task);
        });
        
        // Delete button event listener
        const deleteBtn = taskElement.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this task?')) {
                deleteTask(task.id);
            }
        });
    }
    
    // ===== Task Operations =====
    function toggleTaskCompletion(taskId) {
        fetch(`/api/tasks/${taskId}/toggle`, {
            method: 'PUT'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const taskElement = document.querySelector(`.task-item[data-id="${taskId}"]`);
                taskElement.classList.toggle('completed');
                
                // Refresh the stats
                fetchStatistics();
                
                // Apply filters to refresh the view
                applyFilters();
            }
        })
        .catch(error => {
            console.error('Error toggling task:', error);
        });
    }
    
    function deleteTask(taskId) {
        fetch(`/api/tasks/${taskId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove the task from the DOM
                const taskElement = document.querySelector(`.task-item[data-id="${taskId}"]`);
                taskElement.remove();
                
                // Update the task count
                const tasksCount = document.querySelectorAll('.task-item').length;
                updateTaskCount(tasksCount);
                
                // If no tasks left, show the "no tasks" message
                if (tasksCount === 0) {
                    noTasksElement.style.display = 'flex';
                }
                
                // Refresh the stats
                fetchStatistics();
            }
        })
        .catch(error => {
            console.error('Error deleting task:', error);
        });
    }
    
    function updateTask(taskId, taskData) {
        fetch(`/api/tasks/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(taskData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Refresh task list
                applyFilters();
                
                // Close the modal
                closeTaskModal();
            }
        })
        .catch(error => {
            console.error('Error updating task:', error);
        });
    }
    
    // ===== Modal Handling =====
    function openNewTaskModal() {
        // Reset form
        taskForm.reset();
        taskIdInput.value = '';
        
        // Set modal title
        modalTitle.textContent = 'Add New Task';
        
        // Set form action for POST
        taskForm.action = '/api/tasks';
        taskForm.method = 'POST';
        
        // Show the modal
        taskModal.style.display = 'block';
    }
    
    function openEditTaskModal(task) {
        // Fill the form with task data
        taskIdInput.value = task.id;
        titleInput.value = task.title;
        descriptionInput.value = task.description || '';
        priorityInput.value = task.priority;
        categoryInput.value = task.category || '';
        dueDateInput.value = task.due_date || '';
        
        // Set modal title
        modalTitle.textContent = 'Edit Task';
        
        // We'll handle the submission with JavaScript for PUT request
        taskForm.action = 'javascript:void(0);';
        taskForm.method = 'POST';
        
        // Show the modal
        taskModal.style.display = 'block';
    }
    
    function showTaskDetails(task) {
        // Format created date
        const createdDate = new Date(task.created_at);
        const formattedCreatedDate = new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(createdDate);
        
        // Format due date if exists
        let formattedDueDate = 'No due date';
        if (task.due_date) {
            const dueDate = new Date(task.due_date);
            formattedDueDate = new Intl.DateTimeFormat('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            }).format(dueDate);
        }
        
        // Build content HTML
        const content = `
            <div class="task-details-view">
                <div class="task-detail-header">
                    <h3>${task.title}</h3>
                    <div class="task-badges">
                        <span class="task-priority priority-${task.priority.toLowerCase()}">${task.priority}</span>
                        <span class="task-category">${task.category || 'Uncategorized'}</span>
                        <span class="task-status ${task.completed ? 'status-completed' : 'status-active'}">
                            ${task.completed ? 'Completed' : 'Active'}
                        </span>
                    </div>
                </div>
                
                <div class="task-detail-section">
                    <h4>Description</h4>
                    <p>${task.description || 'No description provided.'}</p>
                </div>
                
                <div class="task-detail-meta">
                    <div class="meta-item">
                        <i class="fas fa-calendar-plus"></i>
                        <span>Created: ${formattedCreatedDate}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Due: ${formattedDueDate}</span>
                    </div>
                </div>
                
                <div class="task-detail-actions">
                    <button class="btn-secondary" onclick="closeTaskDetailsModal()">Close</button>
                    <button class="btn-primary" onclick="editTaskFromDetails(${task.id})">Edit Task</button>
                </div>
            </div>
        `;
        
        // Set the content
        taskDetailsContent.innerHTML = content;
        
        // Show the modal
        taskDetailsModal.style.display = 'block';
    }
    
    function closeTaskModal() {
        taskModal.style.display = 'none';
    }
    
    function closeTaskDetailsModal() {
        taskDetailsModal.style.display = 'none';
    }
    
    // Make these functions available globally
    window.closeTaskDetailsModal = closeTaskDetailsModal;
    window.editTaskFromDetails = function(taskId) {
        // Close details modal
        closeTaskDetailsModal();
        
        // Fetch task data and open edit modal
        fetch(`/api/tasks/${taskId}`)
            .then(response => response.json())
            .then(tasks => {
                const task = tasks.find(t => t.id === taskId);
                if (task) {
                    openEditTaskModal(task);
                }
            })
            .catch(error => {
                console.error('Error fetching task data:', error);
            });
    };
    
    // ===== Filters and Search =====
    function applyFilters() {
        const category = categoryFilter.value;
        const priority = priorityFilter.value;
        const status = statusFilter.value;
        const search = searchInput.value.trim().toLowerCase();
        
        // Build query string
        let queryString = '/api/tasks/filter?';
        if (category !== 'all') queryString += `category=${encodeURIComponent(category)}&`;
        if (priority !== 'all') queryString += `priority=${encodeURIComponent(priority)}&`;
        if (status !== 'all') queryString += `status=${encodeURIComponent(status)}&`;
        if (search) queryString += `search=${encodeURIComponent(search)}`;
        
        // Fetch filtered tasks
        fetch(queryString)
            .then(response => response.json())
            .then(tasks => {
                displayTasks(tasks);
                updateTaskCount(tasks.length);
            })
            .catch(error => {
                console.error('Error fetching filtered tasks:', error);
            });
    }
    
    function updateTaskCount(count) {
        taskCount.textContent = `(${count})`;
    }
    
    // ===== Statistics =====
    function fetchStatistics() {
        fetch('/api/stats')
            .then(response => response.json())
            .then(stats => {
                updateStatistics(stats);
            })
            .catch(error => {
                console.error('Error fetching statistics:', error);
            });
    }
    
    function updateStatistics(stats) {
        totalTasksElement.textContent = stats.total;
        completedTasksElement.textContent = stats.completed;
        pendingTasksElement.textContent = stats.active;
        completionRateElement.textContent = `${stats.completion_rate}%`;
    }
    
    // ===== Event Listeners =====
    // New task button
    newTaskBtn.addEventListener('click', openNewTaskModal);
    
    // Form submission
    taskForm.addEventListener('submit', function(event) {
        // If we're editing a task (has an ID), handle it with JavaScript
        if (taskIdInput.value) {
            event.preventDefault();
            const taskData = {
                title: titleInput.value,
                description: descriptionInput.value,
                priority: priorityInput.value,
                category: categoryInput.value,
                due_date: dueDateInput.value
            };
            updateTask(taskIdInput.value, taskData);
        }
        // Otherwise, let the form submit normally to the POST endpoint
    });
    
    // Cancel button
    cancelBtn.addEventListener('click', closeTaskModal);
    
    // Close buttons for modals
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Find the parent modal
            const modal = button.closest('.modal');
            modal.style.display = 'none';
        });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === taskModal) {
            closeTaskModal();
        } else if (event.target === taskDetailsModal) {
            closeTaskDetailsModal();
        }
    });
    
    // Search and filter listeners
    searchInput.addEventListener('input', function() {
        // Debounce for better performance
        clearTimeout(searchInput.debounceTimer);
        searchInput.debounceTimer = setTimeout(() => {
            applyFilters();
        }, 300);
    });
    
    categoryFilter.addEventListener('change', applyFilters);
    priorityFilter.addEventListener('change', applyFilters);
    statusFilter.addEventListener('change', applyFilters);
    
    // ===== Initialize =====
    // Load tasks when the page loads
    fetchTasks();
});