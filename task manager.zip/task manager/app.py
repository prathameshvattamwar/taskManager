from flask import Flask, render_template, request, jsonify, redirect, url_for
import json
import os
from datetime import datetime

app = Flask(__name__)

# Check if tasks.json exists, if not create it
def initialize_tasks_file():
    if not os.path.exists('tasks.json'):
        with open('tasks.json', 'w') as f:
            json.dump([], f)

# Load tasks from JSON file
def load_tasks():
    initialize_tasks_file()
    with open('tasks.json', 'r') as f:
        return json.load(f)

# Save tasks to JSON file
def save_tasks(tasks):
    with open('tasks.json', 'w') as f:
        json.dump(tasks, f)

# Route for the homepage
@app.route('/')
def index():
    tasks = load_tasks()
    categories = get_unique_categories(tasks)
    return render_template('index.html', tasks=tasks, categories=categories)

# Get unique categories from tasks
def get_unique_categories(tasks):
    categories = set()
    for task in tasks:
        if 'category' in task and task['category']:
            categories.add(task['category'])
    return sorted(list(categories))

# API route to get all tasks
@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    tasks = load_tasks()
    return jsonify(tasks)

# API route to add a new task
@app.route('/api/tasks', methods=['POST'])
def add_task():
    tasks = load_tasks()
    new_task = {
        'id': len(tasks) + 1 if tasks else 1,
        'title': request.form.get('title'),
        'description': request.form.get('description', ''),
        'priority': request.form.get('priority', 'Medium'),
        'category': request.form.get('category', ''),
        'due_date': request.form.get('due_date', ''),
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'completed': False
    }
    tasks.append(new_task)
    save_tasks(tasks)
    return redirect(url_for('index'))

# API route to delete a task
@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    tasks = load_tasks()
    tasks = [task for task in tasks if task['id'] != task_id]
    save_tasks(tasks)
    return jsonify({'success': True})

# API route to toggle task completion status
@app.route('/api/tasks/<int:task_id>/toggle', methods=['PUT'])
def toggle_task(task_id):
    tasks = load_tasks()
    for task in tasks:
        if task['id'] == task_id:
            task['completed'] = not task['completed']
            break
    save_tasks(tasks)
    return jsonify({'success': True})

# API route to update a task
@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    tasks = load_tasks()
    data = request.json
    
    for task in tasks:
        if task['id'] == task_id:
            for key, value in data.items():
                if key in task:
                    task[key] = value
            break
            
    save_tasks(tasks)
    return jsonify({'success': True})

# API route to filter tasks
@app.route('/api/tasks/filter', methods=['GET'])
def filter_tasks():
    tasks = load_tasks()
    category = request.args.get('category')
    priority = request.args.get('priority')
    status = request.args.get('status')
    search = request.args.get('search', '').lower()
    
    filtered_tasks = tasks
    
    if category and category != 'all':
        filtered_tasks = [task for task in filtered_tasks if task.get('category') == category]
    
    if priority and priority != 'all':
        filtered_tasks = [task for task in filtered_tasks if task.get('priority') == priority]
    
    if status:
        if status == 'completed':
            filtered_tasks = [task for task in filtered_tasks if task.get('completed')]
        elif status == 'active':
            filtered_tasks = [task for task in filtered_tasks if not task.get('completed')]
    
    if search:
        filtered_tasks = [
            task for task in filtered_tasks 
            if search in task.get('title', '').lower() or 
               search in task.get('description', '').lower()
        ]
    
    return jsonify(filtered_tasks)

# API route to get task statistics
@app.route('/api/stats', methods=['GET'])
def get_stats():
    tasks = load_tasks()
    
    total = len(tasks)
    completed = sum(1 for task in tasks if task.get('completed'))
    active = total - completed
    
    priorities = {
        'High': sum(1 for task in tasks if task.get('priority') == 'High'),
        'Medium': sum(1 for task in tasks if task.get('priority') == 'Medium'),
        'Low': sum(1 for task in tasks if task.get('priority') == 'Low')
    }
    
    categories = {}
    for task in tasks:
        category = task.get('category', 'Uncategorized')
        if not category:
            category = 'Uncategorized'
        categories[category] = categories.get(category, 0) + 1
    
    return jsonify({
        'total': total,
        'completed': completed,
        'active': active,
        'completion_rate': round((completed / total) * 100 if total > 0 else 0, 1),
        'priorities': priorities,
        'categories': categories
    })

if __name__ == '__main__':
    app.run(debug=True)